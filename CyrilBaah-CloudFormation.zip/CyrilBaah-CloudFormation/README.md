Name: Cyril Baah
Project: CloudFormation 

Link and Snapshots descriptions

LoadBalancer link : http://cloud-webap-ryeie58o3uyh-1059416364.us-east-1.elb.amazonaws.com/

Explaination of Images

AMI-ID: Shows the AMI ID to be used as specificed in the project.
IAMRole: Shows an IAM role created named EC2 with Administrator Access
Cloudformation-stacks: Shows stacks create via cloudformation
Instances: Shows the ec2 instance provisioned by cloudformation
CloudFormationProject2-outputs: Shows the outputs of CloudFormation Project2
CloudFormationProject2-servers-outputs: Shows the outputs of CloudFormationProject2-servers
